﻿

using System;

namespace Expendedoras
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //SIEMPRE QUE OCUPES HERENCIA SE VA A EJECUTAR EL CONSTRUCTOR PADRE
            // SI NO QUISIERA QUE PADRE SE EJECUTARA COMENTAR
            Cafe miCafe = new Cafe(); //expendedora de cafes


            /*

            Console.WriteLine("Entrar en modo mantenimiento, si/no");
            string mantenimiento = Console.ReadLine();
            switch(mantenimiento)
            {
                case "Si":
                    Expendedora miExpendedora = new Expendedora(true); //OBJETO
                    break;
                case "No":
                    miExpendedora = new Expendedora();
                    break;
            }
            //instanciar clase
            */

            Console.ReadLine();
            // EXPENDEDORA BOTON MANTENIMIENTO

        }
    }
}
