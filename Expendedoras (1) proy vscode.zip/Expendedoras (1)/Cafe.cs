﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expendedoras
{
    internal class Cafe: Expendedora // con dos puntos heredamos
    {
    // constructor

        public Cafe() {
            Marca = "Nescafe"; // Marca es el encapsulaod de _marca
            Saludar();
            ClearDisplay();
            Console.WriteLine("Desperta con {0}", Marca);

        }
    }
}
